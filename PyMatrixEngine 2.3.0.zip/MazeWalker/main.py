from menu import Menu
from engine import *


class Game(Application):
    def run(self):
        self.createWindow(600, 400, "Hello")

        self.mainScene = Menu(self.window)
        self.mainScene.isActive = True
        scenes.append(self.mainScene)

        while self.running:
            ec: event.Event = eventCheck(self)
            ScenesRender(self.window, ec)


myGame = Game()
myGame.run()
