import pygame as pg

from engine.scene_renderer import *


def setTitle(title):
    pg.display.set_caption(title)


def setIcon(icon: pg.Surface | pg.SurfaceType):
    pg.display.set_icon(icon)


class Application:
    def __init__(self):
        self.window = None
        self.running = True

    def createWindow(self, width, height, title):
        pg.init()
        pg.display.init()
        self.window = pg.display.set_mode((width, height))
        pg.display.set_caption(title)

    def setTitle(self, title):
        pg.display.set_caption(title)

    def setIcon(self, icon: pg.Surface | pg.SurfaceType):
        pg.display.set_icon(icon)
