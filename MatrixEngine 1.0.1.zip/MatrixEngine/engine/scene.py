class Scene:

    def __init__(self):
        self.background = (255, 255, 255)
        self.isActive = False

    def onUpdate(self, window): ...

    def onRender(self, window): ...
