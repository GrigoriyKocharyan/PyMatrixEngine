from pygame import *


def eventCheck(app):
    for e in event.get():
        if e.type == WINDOWCLOSE:
            app.running = False
        else:
            return e
    return None
