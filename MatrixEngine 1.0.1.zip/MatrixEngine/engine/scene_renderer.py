from pygame import *


class SceneRenderer:

    def __init__(self):
        self.scenes = []

    def render(self, window):
        for scene in self.scenes:
            if scene.isActive:
                scene.onUpdate(window)
                window.fill(scene.background)
                scene.onRender(window)
                display.flip()
