from engine import *
import random


class MyScene(Scene):

    def __init__(self, window):
        self.background = (100, 0, 155)
        self.isActive = False
        self.object = GameObject(10, 10, getImageResource("block.jpg"))
        self.window = window
        self.theme = ButtonTheme(
            (245, 245, 245),
            (215, 215, 215),
            (25, 25, 25),
            (25, 25, 25),
            font.SysFont("Arial", 17),
            17
        )
        self.button = Button("Hello", 10, 10, 200, 80, self.theme)
        self.button.setListener(self.closeWindow)

        self.container = ButtonContainer()
        self.container.addButton(self.button)

    def closeWindow(self, button: Button):
        button.text = ''.join(random.choice(["Hello", "Hi", "Click Me!", "Text", "Ok", "Hi everyone!", "What's up?"]))

    def onUpdate(self, window, currentEvent: event.Event):
        self.object.x = getMouseX()
        self.object.y = getMouseY()

    def onRender(self, window, currentEvent: event.Event):
        self.object.draw(window)
        self.container.draw(window, currentEvent)
