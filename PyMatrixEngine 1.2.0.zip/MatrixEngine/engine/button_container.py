from . import *


class ButtonContainer:
    def __init__(self):
        self.buttons = []
        self.x, self.y = 0, 0

    def addButton(self, button):
        self.buttons.append(button)

    def draw(self, window, currentEvent):
        for button in self.buttons:
            button.currentX = button.x + self.x
            button.currentX = button.y + self.x
            button.draw(window, currentEvent)
