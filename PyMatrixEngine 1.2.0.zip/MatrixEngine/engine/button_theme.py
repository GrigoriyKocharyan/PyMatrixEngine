class ButtonTheme:
    def __init__(self, bgColor, bgHoverColor, textColor, textHoverColor, font, textSize):
        self.bgColor, self.bgHoverColor, self.textColor, self.textHoverColor, self.font, self.textSize = bgColor, bgHoverColor, textColor, textHoverColor, font, textSize
