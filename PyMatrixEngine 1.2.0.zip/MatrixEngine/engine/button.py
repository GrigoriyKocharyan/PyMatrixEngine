from pygame import *

from .button_theme import *
from .mouse_ import *


class Button:
    def __init__(self, text, x, y, width, height, theme: ButtonTheme):
        self.isTouchY = None
        self.isTouchX = None
        self.text, self.x, self.y, self.width, self.height, self.theme = text, x, y, width, height, theme
        self.textVisual: font.Font = theme.font
        self.textRender = self.textVisual.render(self.text, 1, self.theme.textColor)
        self.listener = None
        self.currentX, self.currentY = x, y

    def setListener(self, func):
        self.listener = func

    def draw(self, window, currentEvent: event.Event):

        self.isTouchX: bool = (self.currentX < getMouseX() < self.currentX + self.width)
        self.isTouchY: bool = (self.currentY < getMouseY() < self.currentY + self.height)

        if self.isTouchX and self.isTouchY:
            draw.rect(window, self.theme.bgHoverColor, (self.currentX, self.currentY, self.width, self.height), 0, 3)
            self.textRender = self.textVisual.render(self.text, 1, self.theme.textHoverColor)
            if currentEvent is not None:
                if currentEvent.type == MOUSEBUTTONDOWN:
                    if self.listener is not None:
                        self.listener(self)
        else:
            draw.rect(window, self.theme.bgColor, (self.currentX, self.currentY, self.width, self.height), 0, 3)
            self.textRender = self.textVisual.render(self.text, 1, self.theme.textColor)

        window.blit(
            self.textRender,
            (
                self.currentX + self.width / 2 - self.textRender.get_rect()[2] / 2,
                self.currentY + self.height / 2 - self.textRender.get_rect()[3] / 2
            )
        )
