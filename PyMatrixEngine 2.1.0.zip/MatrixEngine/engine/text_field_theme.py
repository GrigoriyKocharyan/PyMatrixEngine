class TextFieldTheme:
    def __init__(self,
                 bgColor,
                 fgActiveColor,
                 textColor,
                 placeholderColor,
                 font,
                 textSize,
                 roundness,
                 strokeWeight):
        (
            self.bgColor,
            self.bgActiveColor,
            self.textColor,
            self.placeholderColor,
            self.font,
            self.textSize,
            self.roundness,
            self.strokeWeight
        ) = (
            bgColor,
            fgActiveColor,
            textColor,
            placeholderColor,
            font,
            textSize,
            roundness,
            strokeWeight
        )
