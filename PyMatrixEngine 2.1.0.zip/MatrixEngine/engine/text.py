import pygame as p


class Text:
    def __init__(self, text, x, y, font, size, color):
        self.text = text
        self.x, self.y, self.font, self.size, self.color = x, y, font, size, color
        self.tt = p.font.Font(font, size)
        self.rend = self.tt.render(text, 1, color)

    def draw(self, window):
        window.blit(self.rend, (self.x, self.y))


    def update(self, text):
        self.rend = self.tt.render(text, 1, self.color)