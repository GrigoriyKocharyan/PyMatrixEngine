import pygame


class Scene:

    def __init__(self, window):
        self.background = (255, 255, 255)
        self.isActive = False

    def onUpdate(self, window, currentEvent: pygame.event.Event): ...

    def onRender(self, window, currentEvent: pygame.event.Event): ...
