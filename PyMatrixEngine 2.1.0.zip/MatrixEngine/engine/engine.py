from pygame import *
import os


def getImageResource(name):
    dir: str = os.path.abspath(os.curdir)
    dir += "\\res\\"
    print(dir)
    return image.load(dir + name)


def getFontResource(name):
    dir: str = os.path.abspath(os.curdir)
    dir += "\\res\\"
    print(dir)
    return dir + name


def getWindowSize(window):
    return window.get_rect()[2], window.get_rect()[3]


def getWindowWidth(window):
    return window.get_rect()[2]


def getWindowHeight(window):
    return window.get_rect()[3]
