from . import *


class TextFieldContainer:
    def __init__(self):
        self.text_fields = []
        self.x, self.y = 0, 0

    def addTextField(self, text_field):
        self.text_fields.append(text_field)

    def draw(self, window, currentEvent):
        for tf in self.text_fields:
            tf.currentX = tf.x + self.x
            tf.currentY = tf.y + self.y
            tf.draw(window, currentEvent)
