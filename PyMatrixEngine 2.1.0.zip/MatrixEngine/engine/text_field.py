from pygame import *

from .text_field_theme import *
from .mouse_ import *


class TextField:
    def __init__(self, placeholder, x, y, width, height, theme: TextFieldTheme):
        self.isTouchY = None
        self.isTouchX = None
        self.placeholder, self.x, self.y, self.width, self.height, self.theme = placeholder, x, y, width, height, theme
        self.textVisual: font.Font = theme.font
        self.textRender = self.textVisual.render(self.placeholder, 1, self.theme.textColor)
        self.currentX, self.currentY = x, y
        self.isActive = False
        self.text = ""
        self.surf = Surface((width, height), SRCALPHA, 32)
        self.surf = self.surf.convert_alpha()

    def getText(self):
        return self.text

    def draw(self, window, currentEvent: event.Event):

        self.isTouchX: bool = (self.currentX < getMouseX() < self.currentX + self.width)
        self.isTouchY: bool = (self.currentY < getMouseY() < self.currentY + self.height)

        window.blit(self.surf, (self.currentX, self.currentY))

        if self.isTouchX and self.isTouchY:

            if currentEvent is not None:
                if currentEvent.type == MOUSEBUTTONDOWN:

                    if self.isActive:
                        self.isActive = False
                    else:
                        self.isActive = True
        else:
            if currentEvent is not None:
                if currentEvent.type == MOUSEBUTTONDOWN:
                    self.isActive = False

        draw.rect(self.surf, self.theme.bgColor, (0, 0, self.width, self.height), 0, self.theme.roundness)



        if self.isActive:
            draw.rect(self.surf, self.theme.bgActiveColor, (0, 0, self.width, self.height), self.theme.strokeWeight,
                      self.theme.roundness)
            if currentEvent is not None and currentEvent.type == KEYDOWN:
                if currentEvent.key == K_BACKSPACE:

                    if len(self.text) == 1:
                        self.text = ""
                    else:
                        self.text = self.text[:-1]
                elif currentEvent.key == K_RETURN:
                    self.isActive = False
                else:
                    self.text += currentEvent.unicode
                    self.textRender = self.textVisual.render(self.text, 1, self.theme.textColor)
                print(self.text)



        if self.text == "":
            self.textRender = self.textVisual.render(self.placeholder, 1, self.theme.placeholderColor)
        else:
            self.textRender = self.textVisual.render(self.text, 1, self.theme.textColor)

        if self.textRender.get_rect()[2] < (self.width - self.height / 1.5):
            self.surf.blit(
                self.textRender,
                (
                    self.height / 3,
                    self.height / 2 - self.textRender.get_rect()[3] / 2
                )
            )
            if self.isActive and self.text != "":
                draw.rect(self.surf,
                      (100, 100, 100),
                          (
                              self.textRender.get_rect()[2] + self.height / 3 + 2,
                              self.height / 4,
                              2,
                              self.height / 2
                          )

                      )
        else:

            self.surf.blit(
                self.textRender,
                (
                    self.height / 3 - self.textRender.get_rect()[2] + (self.width - self.height / 1.5),
                    self.height / 2 - self.textRender.get_rect()[3] / 2
                )
            )
