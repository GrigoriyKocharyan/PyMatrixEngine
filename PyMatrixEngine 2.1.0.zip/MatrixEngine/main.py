from my_scene import MyScene
from engine import *


class Game(Application):
    def run(self):
        self.createWindow(600, 400, "Hello")

        self.mainScene = MyScene(self.window)
        self.mainScene.isActive = True
        self.sceneRenderer.scenes.append(self.mainScene)

        while self.running:
            ec: event.Event = eventCheck(self)
            self.sceneRenderer.render(self.window, ec)


myGame = Game()
myGame.run()
