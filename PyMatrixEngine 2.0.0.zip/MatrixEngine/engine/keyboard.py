import pygame as pg


def isKeyPressed(key) -> bool:
    return pg.key.get_pressed(key)
