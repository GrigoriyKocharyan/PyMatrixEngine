class TextFieldTheme:
    def __init__(self,
                 bgColor,
                 bgActiveColor,
                 textColor,
                 placeholderColor,
                 font,
                 textSize):
        (
            self.bgColor,
            self.bgActiveColor,
            self.textColor,
            self.placeholderColor,
            self.font,
            self.textSize
        ) = (
            bgColor,
            bgActiveColor,
            textColor,
            placeholderColor,
            font,
            textSize
        )
