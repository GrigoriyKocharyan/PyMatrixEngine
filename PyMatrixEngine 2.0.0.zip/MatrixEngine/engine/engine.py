from pygame import *
import os


def getImageResource(name):
    dir: str = os.path.abspath(os.curdir)
    dir += "\\res\\"
    print(dir)
    return image.load(dir + name)


def getFontResource(name):
    dir: str = os.path.abspath(os.curdir)
    dir += "\\res\\"
    print(dir)
    return dir + name
