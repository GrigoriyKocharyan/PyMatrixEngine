from pygame import *


class SceneRenderer:

    def __init__(self):
        self.scenes = []

    def render(self, window, currentEvent):
        for scene in self.scenes:
            if scene.isActive:
                scene.onUpdate(window, currentEvent)
                window.fill(scene.background)
                scene.onRender(window, currentEvent)
                display.flip()
