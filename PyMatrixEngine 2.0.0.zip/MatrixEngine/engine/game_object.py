from pygame import *


class GameObject:
    def __init__(self, x, y, texture):
        self.x = x
        self.y = y
        self.sprite = texture

    def draw(self, window):
        window.blit(self.sprite, (self.x, self.y))
