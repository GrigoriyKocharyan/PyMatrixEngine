from engine import *
import random


def closeWindow(button):
    button.text = ''.join(random.choice(["Hello", "Hi", "Click Me!", "Text", "Ok", "Hi everyone!", "What's up?"]))


class MyScene(Scene):

    def __init__(self, window):
        self.background = (100, 0, 155)
        self.isActive = False
        self.object = GameObject(10, 10, getImageResource("block.jpg"))
        self.window = window
        self.theme = ButtonTheme(
            (245, 245, 245),
            (215, 215, 215),
            (25, 25, 25),
            (25, 25, 25),
            font.SysFont("Arial", 17),
            17
        )
        self.button = Button("Hello", 10, 10, 200, 80, self.theme)
        self.button.setListener(closeWindow)
        self.button.x = 100

        self.textfield_theme = TextFieldTheme(
            (245, 245, 245),
            (0, 255, 100),
            (25, 25, 25),
            (65, 65, 65),
            font.SysFont("Arial", 17),
            17
        )

        self.textfield = TextField("Введите текст", 10, 200, 200, 40, self.textfield_theme)

        self.container = TextFieldContainer()
        self.container.addTextField(self.textfield)

        self.text = Text("Welcome to PME!", 300, 50, getFontResource("roboto.ttf"), 30, (155, 0, 255))

    def onUpdate(self, window, currentEvent: event.Event):
        self.object.x = getMouseX()
        self.object.y = getMouseY()

        if self.textfield.isActive:
            self.text.update(self.textfield.getText())

    def onRender(self, window, currentEvent: event.Event):
        self.object.draw(window)
        self.button.draw(window, currentEvent)
        self.container.draw(window, currentEvent)
        self.text.draw(window)
