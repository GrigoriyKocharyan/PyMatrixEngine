from pygame import *


class GameObject:
    def __init__(self, x, y, texture):
        self.x = x
        self.y = y
        self.sprite = texture

    def draw(self, window):
        window.blit(self.sprite, (self.x, self.y))

    def setSizeSmoothly(self, width, height):
        self.sprite = transform.smoothscale(self.sprite, (width, height))

    def setSize(self, width, height):
        self.sprite = transform.scale(self.sprite, (width, height))

    def setRotation(self, value):
        self.sprite = transform.rotate(self.sprite, value)
