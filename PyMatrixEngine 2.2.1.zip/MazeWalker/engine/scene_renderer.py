from pygame import *

scenes = []


def ScenesRender(window, currentEvent):
    for scene in scenes:
        if scene.isActive:
            scene.onUpdate(window, currentEvent)
            window.fill(scene.background)
            scene.onRender(window, currentEvent)
            display.flip()
