from src.engine.matrixengine import *


class MyScene(Scene):
    def __init__(self):
        self.background = (100, 0, 155)
        self.isActive = False
        self.object = GameObject(10, 10, getImageResource("block.jpg"))

    def onUpdate(self, window):
        self.object.x = mouse.get_pos()[0]
        self.object.y = mouse.get_pos()[1]

    def onRender(self, window):
        self.object.draw(window)
