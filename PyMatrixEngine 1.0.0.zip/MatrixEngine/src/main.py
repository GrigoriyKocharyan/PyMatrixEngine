from my_scene import MyScene
from engine.matrixengine import *


class Game(Application):
    def run(self):
        self.createWindow(600, 400, "Hello")

        self.mainScene = MyScene()
        self.mainScene.isActive = True
        self.sceneRenderer.scenes.append(self.mainScene)

        while self.running:
            ec = eventCheck(self)
            self.sceneRenderer.render(self.window)


myGame = Game()
myGame.run()
