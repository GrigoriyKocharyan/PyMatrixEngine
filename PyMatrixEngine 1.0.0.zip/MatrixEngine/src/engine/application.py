import pygame as pg

from src.engine.scene_renderer import SceneRenderer


class Application:
    def __init__(self):
        self.window = None
        self.sceneRenderer = SceneRenderer()
        self.running = True

    def createWindow(self, width, height, title):
        pg.init()
        pg.display.init()
        self.window = pg.display.set_mode((width, height))
        pg.display.set_caption(title)
