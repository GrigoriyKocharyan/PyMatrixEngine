from pygame import *
import os


def getImageResource(name):
    dir = os.path.abspath(os.curdir)
    all = dir.split("\\")
    all.pop(len(all) - 1)
    absol = ""
    for i in all:
        absol += i
        absol += "\\"
    absol += "res\\"
    return image.load(absol + name)

