import pygame as pg

def isButtonPressed(button):
    return pg.mouse.get_pressed(button)

def