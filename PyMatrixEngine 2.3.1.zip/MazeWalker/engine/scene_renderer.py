from pygame import *

scenes = {}


def addScene(scene, name):
    scenes[name] = scene


def ScenesRender(window, currentEvent):
    try:
        for scene in scenes:
            if scenes[scene].isActive:
                scenes[scene].onUpdate(window, currentEvent)
                window.fill(scenes[scene].background)
                scenes[scene].onRender(window, currentEvent)
                display.flip()

    except RuntimeError as error:
        pass
