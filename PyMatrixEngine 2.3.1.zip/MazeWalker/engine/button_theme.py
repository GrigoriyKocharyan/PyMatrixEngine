class ButtonTheme:
    def __init__(self, bgColor, bgHoverColor, textColor, textHoverColor, font, textSize, roundness):
        self.bgColor, self.bgHoverColor, self.textColor, self.textHoverColor, self.font, self.textSize, self.roundness = (
            bgColor, bgHoverColor, textColor, textHoverColor, font, textSize, roundness)
