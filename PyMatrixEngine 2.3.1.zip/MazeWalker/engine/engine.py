from pygame import *
import os


def getImageResource(name):
    dir: str = os.path.abspath(os.curdir)
    dir += "\\res\\"
    return image.load(dir + name)


def getFontResource(name):
    dir: str = os.path.abspath(os.curdir)
    dir += "\\res\\"
    return dir + name


def getWindowSize(window):
    return window.get_rect()[2], window.get_rect()[3]


def getWindowWidth(window):
    return window.get_rect()[2]


def getWindowHeight(window):
    return window.get_rect()[3]
