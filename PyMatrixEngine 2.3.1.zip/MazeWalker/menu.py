from engine import *
from levels import *


class Menu(Scene):

    def levelsButton(self, button: Button):
        self.isActive = False
        levelsScene = Levels(self.window)
        levelsScene.isActive = True
        addScene(levelsScene, "levels")

    def __init__(self, window):
        self.background = (30, 30, 30)
        self.isActive = False

        self.window = window
        self.winW = getWindowWidth(self.window)
        self.winH = getWindowHeight(self.window)

        self.font = font.Font(getFontResource("roboto.ttf"), 20)

        self.buttonTheme = ButtonTheme(
            (50, 50, 50), (120, 80, 120),
            (230, 230, 230), (250, 250, 250),
            self.font, 30, 10
        )

        self.button = Button(
            "Уровни", self.winW / 2 - 100, 100, 200, 70, self.buttonTheme
        )
        self.button.setListener(self.levelsButton)

    def onUpdate(self, window, currentEvent: event.Event):
        ...

    def onRender(self, window, currentEvent: event.Event):
        self.button.draw(window, currentEvent)
