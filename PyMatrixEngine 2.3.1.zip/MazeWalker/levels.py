from engine import *
from level_1 import *

class Levels(Scene):

    def returnToMenu(self, button: Button):
        scenes['menu'].isActive = True
        self.isActive = False

    def firstLevel(self, button):

        level1Scene = Level_1(self.window)

        addScene(level1Scene, 'level1')
        level1Scene.isActive = True
        self.isActive = False


    def __init__(self, window):

        self.background = (30, 30, 30)
        self.isActive = False

        self.window = window
        self.winW = getWindowWidth(self.window)
        self.winH = getWindowHeight(self.window)

        self.currentEvent = None

        self.font = font.Font(getFontResource("roboto.ttf"), 20)

        self.buttonTheme = ButtonTheme(
            (50, 50, 50), (120, 80, 120),
            (230, 230, 230), (250, 250, 250),
            self.font, 30, 10
        )

        self.returnButton = Button(
            "Назад", 20, 15, 100, 40, self.buttonTheme
        )
        self.returnButton.setListener(self.returnToMenu)

        self.level1 = Button(
            "1", 20, 70 + 20, 100, 100, self.buttonTheme
        )
        self.level1.setListener(self.firstLevel)

    def onUpdate(self, window, currentEvent: event.Event):
        self.currentEvent = currentEvent

    def onRender(self, window, currentEvent: event.Event):
        draw.rect(window, (35, 35, 35), (0, 0, getWindowWidth(window), 70))
        self.returnButton.draw(window, currentEvent)
        self.level1.draw(window, currentEvent)
