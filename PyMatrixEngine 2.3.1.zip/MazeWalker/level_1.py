from engine import *


class Level_1(Scene):

    def __init__(self, window):

        self.background = (200, 30, 30)
        self.isActive = False

        self.window = window
        self.winW = getWindowWidth(self.window)
        self.winH = getWindowHeight(self.window)

        self.currentEvent = None

        self.font = font.Font(getFontResource("roboto.ttf"), 20)

        self.buttonTheme = ButtonTheme(
            (50, 50, 50), (120, 80, 120),
            (230, 230, 230), (250, 250, 250),
            self.font, 30, 10
        )

    def onUpdate(self, window, currentEvent: event.Event):
        self.currentEvent = currentEvent

    def onRender(self, window, currentEvent: event.Event):
        draw.rect(window, (35, 35, 35), (0, 0, getWindowWidth(window), 70))

