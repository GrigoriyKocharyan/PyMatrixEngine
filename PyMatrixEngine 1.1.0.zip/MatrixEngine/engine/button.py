from pygame import *

from .button_theme import *
from .mouse_ import *

class Button:
    def __init__(self, text, x, y, width, height, theme: ButtonTheme):
        self.text, self.x, self.y, self.width, self.height, self.theme = text, x, y, width, height, theme
        self.textvisual: font.Font = theme.font
        self.textrender = self.textvisual.render(self.text, 1, self.theme.textColor)
        self.listener = None

    def setListener(self, func):
        self.listener = func

    def draw(self, window, currentEvent: pg.event.Event):


        self.isTouchX: bool = (self.x < getMouseX() < self.x + self.width)
        self.isTouchY: bool = (self.y < getMouseY() < self.y + self.height)

        if (self.isTouchX and self.isTouchY):
            draw.rect(window, self.theme.bgHoverColor, (self.x, self.y, self.width, self.height), 0, 3)
            self.textrender = self.textvisual.render(self.text, 1, self.theme.textHoverColor)
            if currentEvent != None:
                if currentEvent.type == MOUSEBUTTONDOWN:
                    if (self.listener != None):
                        self.listener(self)
        else:
            draw.rect(window, self.theme.bgColor, (self.x, self.y, self.width, self.height), 0, 3)
            self.textrender = self.textvisual.render(self.text, 1, self.theme.textColor)

        window.blit(
            self.textrender,
            (
                self.x + self.width / 2 - self.textrender.get_rect()[2] / 2,
                self.y + self.height / 2 - self.textrender.get_rect()[3] / 2
            )
        )

