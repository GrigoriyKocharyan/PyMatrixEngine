import pygame as pg


def isButtonPressed(button):
    return pg.mouse.get_pressed(button)


def getMouseX():
    return pg.mouse.get_pos()[0]


def getMouseY():
    return pg.mouse.get_pos()[1]
